quarto=[]

def adicionar_quarto(numero):
    q = [numero]
    quarto.append(q)
    
def listar_quartos():
    return quarto

def buscar_quarto(numero):
    for m in quarto:
        if (m[0] == numero):
            return m
    return None

def remover_quarto(numero):
    for m in quarto:
        if (m[0] == numero):
            quarto.remove(m)
            return True
    return False

def iniciar_quartos():
    adicionar_quarto(1)
