internamento=[]

def internar_paciente(cod_paciente, cod_medico, numero_quarto):
    inter = [cod_paciente, cod_medico, numero_quarto]
    internamento.append(inter)
    
def listar_internamentos():
    return internamento

def buscar_internamento(cod_internamento):
    for m in internamento:
        if (m[0] == cod_internamento):
            return m
    return None

def cancelar_internamento(cod_internamento):
    for m in internamento:
        if (m[0] == cod_internamento):
            internamento.remove(m)
            return True
    return False


def iniciar_internamentos():
    adicionar_internamentos(22222222222,432432423, 432432)
    adicionar_internamentos(11111111111,432432, 432432423)
