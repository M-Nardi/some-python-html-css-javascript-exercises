from logica import quarto


def imprimir_quarto(quarto):
    print("Numero: ",quarto)

def menu_adicionar():
    print("\nAdicionar quarto \n")
    numero = int(input("Numero: "))
    quarto.adicionar_quarto(numero)


def menu_listar():
    print("\nListar quartos \n")
    quartos = quarto.listar_quartos()
    for m in quartos:
        imprimir_quarto(m)


def menu_buscar():
    print("\nBuscar quarto por numero \n")
    numero = int(input("Numero: "))
    m = quarto.buscar_quarto(numero)
    if (m == None):
        print("quarto não encontrado")
    else:
        imprimir_quarto(m)


def menu_remover():
    print("\nRemover quarto \n")
    numero = int(input("numero: "))
    m = quarto.remover_quarto(numero)
    if (m == False):
        print("quarto não encontrado")
    else:
        print("quarto removido")


def mostrar_menu():
    run_quarto = True
    menu = ("\n----------------\n" +
            "(1) Adicionar novo quarto \n" +
            "(2) Listar quartos \n" +
            "(3) Buscar quarto por numero \n" +
            "(4) Remover quarto \n" +
            "(0) Voltar\n" +
            "----------------")

    while (run_quarto):
        print(menu)
        op = int(input("Digite sua escolha: "))

        if (op == 1):
            menu_adicionar()
        elif (op == 2):
            menu_listar()
        elif (op == 3):
            menu_buscar()
        elif (op == 4):
            menu_remover()
        elif (op == 0):
            run_quarto = False


if __name__ == "__main__":
    mostrar_menu()
