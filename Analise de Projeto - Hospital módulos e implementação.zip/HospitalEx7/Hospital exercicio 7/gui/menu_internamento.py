from logica import internamento


def imprimir_internamento(internamento):
    print("cod_internamento: ", internamento[0])
    print("Nome: ", internamento[1])
    print("Endereco: ", internamento[2])
    print()


def menu_adicionar():
    print("\nAdicionar internamento \n")
    cod_internamento = int(input("cod_internamento: "))
    cod_medico = str(input("Codigo Medico: "))
    numero_quarto = str(input("Numero Quarto: "))
    internamento.internar_paciente(cod_internamento, cod_medico, numero_quarto)


def menu_listar():
    print("\nListar internamentos \n")
    internamentos = internamento.listar_internamentos()
    for m in internamentos:
        imprimir_internamento(m)


def menu_buscar():
    print("\nBuscar internamento por cod_internamento \n")
    cod_internamento = int(input("cod_internamento: "))
    m = internamento.buscar_internamento(cod_internamento)
    if (m == None):
        print("internamento não encontrado")
    else:
        imprimir_internamento(m)


def menu_cancelar():
    print("\ncancelar internamento \n")
    cod_internamento = int(input("cod_internamento: "))
    m = internamento.cancelar_internamento(cod_internamento)
    if (m == False):
        print("internamento não encontrado")
    else:
        print("internamento removido")


def mostrar_menu():
    run_internamento = True
    menu = ("\n----------------\n" +
            "(1) Adicionar novo internamento \n" +
            "(2) Listar internamentos \n" +
            "(3) Buscar internamento por cod_internamento \n" +
            "(4) cancelar internamento \n" +
            "(0) Voltar\n" +
            "----------------")

    while (run_internamento):
        print(menu)
        op = int(input("Digite sua escolha: "))

        if (op == 1):
            menu_adicionar()
        elif (op == 2):
            menu_listar()
        elif (op == 3):
            menu_buscar()
        elif (op == 4):
            menu_cancelar()
        elif (op == 0):
            run_internamento = False


if __name__ == "__main__":
    mostrar_menu()
