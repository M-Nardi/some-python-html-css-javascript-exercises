from gui import menu_geral

def principal():
    menu_geral.mostrar_menu()

if __name__ == "__main__":
    principal()
