import random
def ex03():
    matriz1=[]
    matriz2=[]
    linha1=int(input("Digite o numero de linhas: "))
    coluna1=int(input("Digite o numero de colunas"))
    for i in range(linha1):
        matriz1.append([])
        for a in range(coluna1):
            matriz1[i].append(random.randint(1,100))
    for i in range(linha1):
        print(matriz1[i])
    print ("TRANSPOSTA")
    for i in range(coluna1):
        matriz2.append([])
        for c in range(linha1):
            matriz2[i].append([matriz1[c][i]])
    for i in range(coluna1):
        print(matriz2[i])
    if matriz1==matriz2:
        print ("É hermitiniana")
    else:
        print ("Não é hermitiniana")
ex03()
