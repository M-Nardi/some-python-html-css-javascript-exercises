def multiplicacao_matriz():
    import random
    matriz1 = []
    matriz2 = []
    matriz3 = []
    sup1=0
    sup2=0
    sup=0
    linhas1 = int(input("Digite quantas linhas terá matriz 1: " ))
    colunas1 = int(input("Informe a quantidade de colunas da matriz 1:" ))
    for i in range(linhas1):
         matriz1.append([])
         for j in range(colunas1):
            matriz1[i].append(random.randint(0,10))

    linhas2=int(input("Digite quantas linhas terá na matriz 2: "))
    colunas2=int(input("Digite quantas colunas terá na matriz 2: "))
    for i2 in range(linhas2):
        matriz2.append([])
        for z in range(colunas2):
            matriz2[i2].append(random.randint(0,10))
    if colunas1!=linhas2 or colunas2!=linhas1:
        print("Não ha produto")
    else:
        if linhas1>=colunas1:
            for i in range(linhas1):
                matriz3.append([])
                for b in range(colunas2):
                    for c in range(linhas2):
                        sup=sup+(matriz1[i][c]*matriz2[c][b])
                        print(i)
                    matriz3[i].append(sup)
                    sup=0
            print("MATRIZ1")
            for i in range(linhas1):
                print(matriz1[i])
            print("MATRIZ2")
            for i in range(linhas2):
                print(matriz2[i])
            print("RESULTADO:")
            for i in range(linhas1):
                print(matriz3[i])
multiplicacao_matriz()
