arquivo = open('times.txt', 'r')
lista = []
for times in arquivo:
    print (times.rstrip())
    lista.append(times)
lista.sort()
print (lista)
