arquivo = open('times.txt', 'r')
for times in arquivo:
    print (times.rstrip())
    print (times.split(":"))
    
