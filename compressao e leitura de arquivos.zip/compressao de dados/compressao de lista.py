nome = 'Fabio'
vogais = [letra for letra in nome if letra in "aeiou"]
print (vogais)
